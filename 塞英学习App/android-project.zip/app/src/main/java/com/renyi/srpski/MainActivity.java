package com.renyi.srpski;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private SpeechRecognizer rec;
    private String pendingLang = null;
    private static final int REQ_MIC = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#58cc02"));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidTTS");
        setContentView(web);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }

        tts = new TextToSpeech(this, status -> ttsReady = (status == TextToSpeech.SUCCESS));
    }

    private Locale pick(String lang) {
        if (tts == null || !ttsReady) return null;
        Locale[] cands = "sr".equals(lang)
                ? new Locale[]{new Locale("sr", "RS"), new Locale("sr"), new Locale("hr", "HR"), new Locale("hr"), new Locale("bs")}
                : new Locale[]{Locale.US, Locale.UK, Locale.ENGLISH};
        for (Locale l : cands) {
            try {
                if (tts.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE) return l;
            } catch (Exception ignored) { }
        }
        return null;
    }

    /* ---------- 甜美女声：自动挑女声音色 ---------- */

    // 已知是女声的 Google 语音代号（语音名里 -x-后面那段）
    private static final String[] FEMALE_IDS = {
            "sfg", "tpc", "tpf", "iob", "iog", "gba", "gbc", "gbg", "aua", "auc"};
    // 已知是男声的代号
    private static final String[] MALE_IDS = {
            "iol", "iom", "tpd", "gbb", "gbd", "rjs", "aub", "aud"};

    /** 1 = 女声，-1 = 男声，0 = 不知道 */
    private static int gender(Voice v) {
        String n = v.getName().toLowerCase(Locale.ROOT);
        try {
            Set<String> f = v.getFeatures();
            if (f != null) {
                for (String x : f) {
                    String y = x.toLowerCase(Locale.ROOT);
                    if (y.contains("female")) return 1;
                    if (y.contains("male")) return -1;
                }
            }
        } catch (Exception ignored) { }
        if (n.contains("female")) return 1;
        if (n.contains("male")) return -1;
        // 三星语音：…SMTf00 = 女，…SMTm00 = 男
        if (n.matches(".*smt?f\\d+.*") || n.matches(".*[-_]f\\d+.*")) return 1;
        if (n.matches(".*smt?m\\d+.*") || n.matches(".*[-_]m\\d+.*")) return -1;
        for (String id : FEMALE_IDS) if (n.contains("-x-" + id)) return 1;
        for (String id : MALE_IDS) if (n.contains("-x-" + id)) return -1;
        return 0;
    }

    private static boolean langMatch(Voice v, String lang) {
        Locale l = v.getLocale();
        if (l == null) return false;
        String c = l.getLanguage();
        if ("sr".equals(lang)) return "sr".equals(c) || "hr".equals(c) || "bs".equals(c) || "sh".equals(c);
        return "en".equals(c);
    }

    private static boolean needsNet(Voice v) {
        try {
            return v.isNetworkConnectionRequired()
                    || v.getName().toLowerCase(Locale.ROOT).contains("network");
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean notInstalled(Voice v) {
        try {
            Set<String> f = v.getFeatures();
            return f != null && f.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED);
        } catch (Exception e) {
            return false;
        }
    }

    /** 给一个语言挑最合适的音色：用户指定的 > 女声 > 本地可离线 > 塞语优先于克语 > 音质高 */
    private Voice chooseVoice(String lang, String wanted) {
        if (tts == null || !ttsReady) return null;
        Set<Voice> all;
        try { all = tts.getVoices(); } catch (Exception e) { return null; }
        if (all == null) return null;
        Voice best = null;
        int bestScore = Integer.MIN_VALUE;
        for (Voice v : all) {
            if (!langMatch(v, lang) || notInstalled(v)) continue;
            if (wanted != null && !wanted.isEmpty() && wanted.equals(v.getName())) return v;
            int sc = 0;
            int g = gender(v);
            sc += g == 1 ? 1000 : (g == 0 ? 400 : 0);
            sc += needsNet(v) ? 0 : 200;
            String c = v.getLocale().getLanguage();
            if ("sr".equals(lang)) sc += "sr".equals(c) ? 60 : ("hr".equals(c) ? 40 : 0);
            else {
                String ctry = v.getLocale().getCountry();
                sc += "US".equals(ctry) ? 60 : ("GB".equals(ctry) ? 40 : 0);
            }
            sc += Math.min(v.getQuality(), 500) / 10;
            if (sc > bestScore) { bestScore = sc; best = v; }
        }
        return best;
    }

    public class Bridge {
        @JavascriptInterface
        public void speak(String text, String lang, float rate) {
            speak2(text, lang, rate, 1.15f, "");
        }

        /** 新版朗读：可调音调 pitch（1.0 正常，越大越清脆甜美），可指定音色名 */
        @JavascriptInterface
        public void speak2(String text, String lang, float rate, float pitch, String voiceName) {
            if (tts == null || !ttsReady) return;
            Voice v = null;
            try { v = chooseVoice(lang, voiceName); } catch (Exception ignored) { }
            boolean ok = false;
            if (v != null) {
                try { ok = tts.setVoice(v) == TextToSpeech.SUCCESS; } catch (Exception ignored) { }
            }
            if (!ok) {
                Locale l = pick(lang);
                if (l != null) tts.setLanguage(l);
            }
            tts.setSpeechRate(rate);
            tts.setPitch(Math.max(0.5f, Math.min(2.0f, pitch)));
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt");
        }

        /** 列出某语言的全部音色，给设置页选择用 */
        @JavascriptInterface
        public String voices(String lang) {
            JSONArray arr = new JSONArray();
            if (tts == null || !ttsReady) return arr.toString();
            try {
                Voice auto = chooseVoice(lang, "");
                for (Voice v : tts.getVoices()) {
                    if (!langMatch(v, lang) || notInstalled(v)) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", v.getName());
                    o.put("lang", v.getLocale().toLanguageTag());
                    o.put("g", gender(v));
                    o.put("net", needsNet(v));
                    o.put("q", v.getQuality());
                    o.put("auto", auto != null && auto.getName().equals(v.getName()));
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public String status() {
            Locale sr = pick("sr");
            Locale en = pick("en");
            return "{\"ready\":" + ttsReady
                    + ",\"sr\":\"" + (sr == null ? "" : sr.toLanguageTag()) + "\""
                    + ",\"en\":\"" + (en == null ? "" : en.toLanguageTag()) + "\"}";
        }

        @JavascriptInterface
        public boolean canListen() {
            try {
                return SpeechRecognizer.isRecognitionAvailable(MainActivity.this);
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(() -> startListen(lang));
        }

        @JavascriptInterface
        public void stopListen() {
            runOnUiThread(() -> {
                if (rec != null) {
                    try { rec.stopListening(); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void post(final String id, final String url, final String headersJson, final String body) {
            new Thread(() -> {
                int code = -1;
                String text = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(90000);
                    c.setDoOutput(true);
                    JSONObject h = new JSONObject(headersJson);
                    Iterator<String> it = h.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.setRequestProperty(k, h.getString(k));
                    }
                    byte[] b = body.getBytes(StandardCharsets.UTF_8);
                    c.setFixedLengthStreamingMode(b.length);
                    OutputStream os = c.getOutputStream();
                    os.write(b);
                    os.close();
                    code = c.getResponseCode();
                    InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = readAll(is);
                } catch (Exception e) {
                    code = -1;
                    text = String.valueOf(e.getMessage());
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.onHttp&&window.onHttp(" + JSONObject.quote(id) + "," + code + "," + JSONObject.quote(text) + ")";
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
            }).start();
        }

        @JavascriptInterface
        public void get(final String id, final String url, final String headersJson) {
            new Thread(() -> {
                int code = -1;
                String text = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    JSONObject h = new JSONObject(headersJson);
                    Iterator<String> it = h.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.setRequestProperty(k, h.getString(k));
                    }
                    code = c.getResponseCode();
                    InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = readAll(is);
                } catch (Exception e) {
                    code = -1;
                    text = String.valueOf(e.getMessage());
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.onHttp&&window.onHttp(" + JSONObject.quote(id) + "," + code + "," + JSONObject.quote(text) + ")";
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
            }).start();
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent("com.android.settings.TTS_SETTINGS");
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception ignored) { }
                }
            });
        }
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }

    /* ---------- 语音识别（口语对练） ---------- */

    private void startListen(String lang) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) { }
        }
        if (rec != null) {
            try { rec.destroy(); } catch (Exception ignored) { }
            rec = null;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            emit("error", null, -1);
            return;
        }
        try {
            rec = SpeechRecognizer.createSpeechRecognizer(this);
            rec.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { emit("ready", null, 0); }
                @Override public void onBeginningOfSpeech() { emit("begin", null, 0); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { emit("end", null, 0); }
                @Override public void onError(int error) { emit("error", null, error); }
                @Override public void onResults(Bundle results) {
                    emit("result", results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION), 0);
                }
                @Override public void onPartialResults(Bundle partial) {
                    emit("partial", partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION), 0);
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            rec.startListening(i);
        } catch (Exception e) {
            emit("error", null, -1);
        }
    }

    private void emit(String type, ArrayList<String> texts, int code) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("code", code);
            JSONArray arr = new JSONArray();
            if (texts != null) for (String t : texts) arr.put(t);
            o.put("texts", arr);
            final String js = "window.onSpeech&&window.onSpeech(" + o.toString() + ")";
            runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
        } catch (Exception ignored) { }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_MIC) return;
        String lang = pendingLang;
        pendingLang = null;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && lang != null) {
            startListen(lang);
        } else {
            emit("error", null, 9);
        }
    }

    @Override
    protected void onPause() {
        if (rec != null) {
            try { rec.cancel(); } catch (Exception ignored) { }
            emit("error", null, 5);
        }
        super.onPause();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.appBack && window.appBack()) ? '1' : '0'", v -> {
            if (!"\"1\"".equals(v)) finish();
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (rec != null) {
            try { rec.destroy(); } catch (Exception ignored) { }
        }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
